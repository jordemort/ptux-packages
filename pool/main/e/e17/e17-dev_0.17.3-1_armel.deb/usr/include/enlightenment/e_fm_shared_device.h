#ifndef E_FM_SHARED_DEVICE_H
#define E_FM_SHARED_DEVICE_H

#include "e_fm_shared_types.h"

void _e_fm_shared_device_storage_free(E_Storage *s);
void _e_fm_shared_device_volume_free(E_Volume *v);

#endif
